@echo off
REM ============================================================
REM  DeskTracker — Build Script
REM  Run this on a Windows machine with Python 3.9+ installed.
REM ============================================================

echo.
echo ====================================
echo   DeskTracker EXE Builder
echo ====================================
echo.

REM 1. Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found in PATH. Install Python 3.9+ first.
    pause
    exit /b 1
)

REM 2. Install / upgrade dependencies
echo [1/3] Installing dependencies...
pip install --upgrade pyinstaller pywin32 psutil pynput oracledb
if errorlevel 1 (
    echo [ERROR] pip install failed. Check your Python environment.
    pause
    exit /b 1
)

REM 3. Ensure pywin32 post-install step is done
echo [2/3] Running pywin32 post-install...
python -c "import win32api" >nul 2>&1
if errorlevel 1 (
    python Scripts\pywin32_postinstall.py -install >nul 2>&1
)

REM 4. Build
echo [3/3] Building EXE with PyInstaller...
pyinstaller --clean --noconfirm desktracker.spec

if errorlevel 1 (
    echo.
    echo [ERROR] Build failed. Check the output above for details.
    pause
    exit /b 1
)

echo.
echo ====================================
echo   BUILD SUCCESSFUL!
echo   Output: dist\DeskTracker.exe
echo ====================================
echo.
echo Set these environment variables before running:
echo   DB_USER                       Oracle username
echo   DB_PASS                       Oracle password
echo   DB_DSN                        Oracle DSN
echo   DESKTRACKER_IDLE_THRESHOLD    Idle seconds (default: 300)
echo   DESKTRACKER_BATCH_INTERVAL    Batch flush seconds (default: 900)
echo.
pause
