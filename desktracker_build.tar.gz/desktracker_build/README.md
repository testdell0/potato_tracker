# DeskTracker — Build to EXE

## Prerequisites
- **Windows 10/11** (the app uses Win32 APIs)
- **Python 3.9+** installed and in PATH
- **pip** available

## Quick Build

1. Copy this entire folder to your Windows machine.
2. Double-click **`build.bat`** (or run it from a terminal).
3. The EXE will appear at **`dist\DeskTracker.exe`**.

That's it! The batch script handles installing PyInstaller and all dependencies.

## Environment Variables

Set these **before** running `DeskTracker.exe`:

| Variable | Required | Default | Description |
|---|---|---|---|
| `DB_USER` | Yes | `your_username` | Oracle DB username |
| `DB_PASS` | Yes | `your_password` | Oracle DB password |
| `DB_DSN` | Yes | `your_dsn` | Oracle connection string |
| `DESKTRACKER_IDLE_THRESHOLD` | No | `300` | Seconds of no input before user is "idle" |
| `DESKTRACKER_BATCH_INTERVAL` | No | `900` | Seconds between DB batch flushes |
| `DESKTRACKER_LOG_FILE` | No | `desktracker.log` | Log file path |

**Example (PowerShell):**
```powershell
$env:DB_USER = "scott"
$env:DB_PASS = "tiger"
$env:DB_DSN  = "myhost:1521/ORCL"
.\dist\DeskTracker.exe
```

**Example (CMD):**
```cmd
set DB_USER=scott
set DB_PASS=tiger
set DB_DSN=myhost:1521/ORCL
dist\DeskTracker.exe
```

## Notes

- The EXE runs with a **console window** so you can see logs in real-time. To hide it, open `desktracker.spec` and change `console=True` to `console=False`.
- To add a **custom icon**, place an `.ico` file in this folder and uncomment the `icon=` line in the spec file.
- Press **Ctrl+C** in the console to gracefully stop the tracker (it will flush remaining data to the DB).
- The build uses `--onefile` mode (single EXE) via the spec file. First launch may be slightly slower as it unpacks to a temp directory.

## Bug Fix Applied

The original script had `IDLE_THRESHOLD` and `BATCH_INTERVAL_SECONDS` calling `int()` on `os.getenv(...)` without default values, which would crash if those env vars weren't set. Defaults of `300` and `900` seconds have been added.

## Log Index Fix

The `db_writer` log message referenced wrong tuple indices (`row[7]`, `row[8]`, `row[9]`). Fixed to use the correct indices (`row[2]`, `row[3]`, `row[4]`) matching `total_seconds`, `active_seconds`, and `session_count`.
