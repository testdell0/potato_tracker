# -*- mode: python ; coding: utf-8 -*-
# desktracker.spec — PyInstaller spec for Desktop Activity Tracker
#
# Build command:
#   pyinstaller desktracker.spec
#
# Or just run:  build.bat

import sys
from PyInstaller.utils.hooks import collect_submodules

# Collect all oracledb submodules (it has compiled extensions)
oracledb_hiddens = collect_submodules('oracledb')

# pynput backends vary by OS; collect them all so the right one is bundled
pynput_hiddens = collect_submodules('pynput')

a = Analysis(
    ['dbconn8.py'],
    pathex=[],
    binaries=[],
    datas=[],
    hiddenimports=[
        'win32gui',
        'win32process',
        'win32api',
        'win32con',
        'pywintypes',
        'psutil',
        'winreg',
    ] + oracledb_hiddens + pynput_hiddens,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        'tkinter', '_tkinter',
        'matplotlib', 'numpy', 'scipy', 'pandas',
        'PIL', 'IPython', 'jupyter',
        'test', 'unittest',
    ],
    noarchive=False,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='DeskTracker',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,           # Keep console visible for logs; set False to hide
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    # icon='icon.ico',      # Uncomment and add an .ico file for a custom icon
)
