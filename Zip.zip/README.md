# DeskTracker — Build & Deployment Guide

## Project Files

| File                  | Purpose                                           |
|-----------------------|---------------------------------------------------|
| `dbconnf.py`          | Main Python source code                           |
| `requirements.txt`    | Python dependencies                               |
| `desktracker.spec`    | PyInstaller build specification                   |
| `build.bat`           | One-click build script (installs deps + builds)   |
| `set_env.bat`         | Template to set environment variables              |
| `run_desktracker.bat` | One-click launcher (sets env + runs exe)           |

---

## Prerequisites

- **Python 3.9+** installed and added to PATH
- **Windows 10/11** (uses Win32 APIs)

---

## Quick Build (3 steps)

1. Put all files in one folder
2. Edit `set_env.bat` with your Oracle DB credentials
3. Double-click `build.bat`

Your executable will appear at `dist\DeskTracker.exe`.

---

## Running

### Option A — Use the launcher
1. Copy `run_desktracker.bat` into the `dist\` folder
2. Edit the DB credentials inside it
3. Double-click `run_desktracker.bat`

### Option B — Set env vars manually
1. Open a terminal
2. Run `set_env.bat` (after editing credentials)
3. Run `dist\DeskTracker.exe`

---

## Required Environment Variables

| Variable                      | Example                          |
|-------------------------------|----------------------------------|
| `DB_USER`                     | `scott`                          |
| `DB_PASS`                     | `tiger`                          |
| `DB_DSN`                      | `dbhost:1521/ORCL`               |
| `DESKTRACKER_IDLE_THRESHOLD`  | `300` (seconds)                  |
| `DESKTRACKER_BATCH_INTERVAL`  | `60`  (seconds)                  |

---

## Troubleshooting

- **Missing DLL errors**: Ensure `pywin32` installed correctly. Run `python -m pywin32_postinstall -install` inside venv.
- **pynput not capturing input**: Run the exe as Administrator.
- **Oracle connection fails**: Verify DSN, firewall, and that thin mode works for your DB version.
- **Antivirus blocks the exe**: Add `dist\DeskTracker.exe` to your antivirus exclusions. PyInstaller executables are commonly flagged as false positives.
