@echo off
REM ============================================================
REM  run_desktracker.bat — One-click launcher
REM  Sets environment variables and starts DeskTracker.exe
REM  Place this in the same folder as DeskTracker.exe
REM ============================================================

REM --- Oracle Database Credentials ---
set DB_USER=your_username
set DB_PASS=your_password
set DB_DSN=your_host:1521/your_service_name

REM --- Tracker Settings ---
set DESKTRACKER_IDLE_THRESHOLD=300
set DESKTRACKER_BATCH_INTERVAL=60

REM --- Log file ---
set DESKTRACKER_LOG_FILE=desktracker.log

REM --- Launch ---
start "" "%~dp0DeskTracker.exe"
