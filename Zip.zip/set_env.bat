REM ============================================================
REM  set_env.bat — Set environment variables before running
REM  Edit the values below, then run:   set_env.bat
REM  Then run DeskTracker.exe from the same terminal.
REM ============================================================

@echo off

REM --- Oracle Database Credentials ---
set DB_USER=your_username
set DB_PASS=your_password
set DB_DSN=your_host:1521/your_service_name

REM --- Tracker Settings ---
set DESKTRACKER_IDLE_THRESHOLD=300
set DESKTRACKER_BATCH_INTERVAL=60

REM --- Log file (optional, defaults to desktracker.log) ---
set DESKTRACKER_LOG_FILE=desktracker.log

echo Environment variables set. You can now run DeskTracker.exe
