@echo off
REM ============================================================
REM  build.bat — Install dependencies and build DeskTracker.exe
REM  Run from the project folder:   build.bat
REM ============================================================

echo ============================================
echo   DeskTracker — Build Script
echo ============================================
echo.

REM --- Step 1: Check Python is available ---
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python not found in PATH.
    echo         Install Python 3.9+ from https://python.org
    pause
    exit /b 1
)

REM --- Step 2: Create a virtual environment (optional but recommended) ---
if not exist "venv" (
    echo [1/4] Creating virtual environment...
    python -m venv venv
) else (
    echo [1/4] Virtual environment already exists — reusing.
)

echo [2/4] Activating virtual environment...
call venv\Scripts\activate.bat

REM --- Step 3: Install dependencies ---
echo [3/4] Installing dependencies...
pip install --upgrade pip
pip install -r requirements.txt

REM --- Step 4: Build with PyInstaller ---
echo [4/4] Building DeskTracker.exe ...
pyinstaller --clean desktracker.spec

echo.
if exist "dist\DeskTracker.exe" (
    echo ============================================
    echo   BUILD SUCCESSFUL
    echo   Output: dist\DeskTracker.exe
    echo ============================================
) else (
    echo [ERROR] Build failed. Check the output above.
)

echo.
pause
