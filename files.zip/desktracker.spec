# -*- mode: python ; coding: utf-8 -*-
"""
PyInstaller spec file for DeskTracker.

Usage (run from the project folder):
    pyinstaller desktracker.spec --clean --noconfirm

Output:
    dist/DeskTracker.exe   (single file, no console window)
"""

block_cipher = None

a = Analysis(
    ['desktracker.py'],
    pathex=[],
    binaries=[],
    datas=[],                                # .env is kept EXTERNAL, not bundled
    hiddenimports=[
        # ---- Oracle DB (thin mode) ----
        'oracledb',

        # ---- System monitoring ----
        'psutil',
        'psutil._pswindows',

        # ---- Windows API ----
        'win32gui',
        'win32process',
        'win32api',
        'win32con',
        'pywintypes',
        'winreg',

        # ---- Keyboard/mouse listeners ----
        'pynput',
        'pynput.keyboard',
        'pynput.keyboard._win32',
        'pynput.mouse',
        'pynput.mouse._win32',

        # ---- .env loading ----
        'dotenv',

        # ---- stdlib (sometimes missed) ----
        'ctypes',
        'ctypes.wintypes',
        'queue',
        'getpass',
        'subprocess',
        'logging',
        'logging.handlers',
        'threading',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        # Exclude things you DON'T need — keeps the .exe smaller
        'tkinter',
        'matplotlib',
        'numpy',
        'pandas',
        'scipy',
        'PIL',
        'test',
        'unittest',
        'xmlrpc',
        'pydoc',
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='DeskTracker',                     # ← output filename
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,                               # compress if UPX is on PATH
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,                          # ← FALSE = no black console window
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,                              # ← put your .ico path here if you have one
    # icon='desktracker.ico',
)
