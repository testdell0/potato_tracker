@echo off
REM ============================================================
REM  DeskTracker — Build Script (Windows)
REM  Double-click this file to build DeskTracker.exe
REM ============================================================

echo.
echo ============================================
echo   DeskTracker — Build to .exe
echo ============================================
echo.

REM --- Check Python ---
python --version >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Python not found in PATH.
    echo         Install Python 3.9+ from https://python.org
    echo         Make sure to check "Add Python to PATH" during install.
    pause
    exit /b 1
)
echo [OK] Python found

REM --- Create venv ---
echo.
echo [1/5] Creating virtual environment...
if exist venv (
    echo       venv exists, reusing...
) else (
    python -m venv venv
    if %ERRORLEVEL% neq 0 (
        echo [ERROR] Failed to create virtual environment
        pause
        exit /b 1
    )
)
call venv\Scripts\activate.bat
echo [OK] Virtual environment activated

REM --- Install deps ---
echo.
echo [2/5] Installing dependencies...
pip install --upgrade pip >nul 2>&1
pip install -r requirements.txt
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Dependency installation failed
    pause
    exit /b 1
)
echo [OK] All packages installed

REM --- Build exe ---
echo.
echo [3/5] Building DeskTracker.exe ...
pyinstaller desktracker.spec --clean --noconfirm
if %ERRORLEVEL% neq 0 (
    echo [ERROR] PyInstaller build failed
    echo         Check the output above for details.
    pause
    exit /b 1
)
echo [OK] Build successful

REM --- Copy .env next to exe ---
echo.
echo [4/5] Copying .env to dist folder...
copy /Y .env dist\.env >nul 2>&1
echo [OK] .env copied

REM --- Done ---
echo.
echo [5/5] Creating launch helper...
(
    echo @echo off
    echo cd /d "%%~dp0"
    echo start "" "DeskTracker.exe"
) > dist\start_tracker.bat
echo [OK] start_tracker.bat created

echo.
echo ============================================
echo   BUILD COMPLETE!
echo.
echo   Output folder:  dist\
echo.
echo   Files to deploy:
echo     dist\DeskTracker.exe    (the app)
echo     dist\.env               (your DB credentials)
echo     dist\start_tracker.bat  (optional launcher)
echo.
echo   NEXT STEPS:
echo     1. Edit dist\.env with your real Oracle credentials
echo     2. Double-click DeskTracker.exe (or start_tracker.bat)
echo     3. Tracker runs silently in background
echo     4. Check desktracker.log for activity
echo ============================================
echo.
pause
