# DeskTracker — Build & Deployment Guide

## What Changed from `dbconn3.py`

Your original script is preserved **as-is** in terms of logic. Only three things were added to make it `.exe`-friendly:

1. **`python-dotenv`** — loads the `.env` file automatically (no need to set system env vars)
2. **`get_base_dir()`** — resolves file paths relative to the `.exe` location (not a temp folder)
3. **Log file path fix** — `desktracker.log` is written next to the `.exe`, not in some random CWD

---

## Project Files

```
desktracker_build/
├── desktracker.py          ← Your script (with .env + path fixes)
├── desktracker.spec         ← PyInstaller build config
├── requirements.txt         ← All dependencies
├── .env                     ← Database credentials (edit before running!)
├── build.bat                ← One-click build script
└── README.md                ← This file
```

---

## Step-by-Step: Build the .exe

### Prerequisites
- **Windows 10/11**
- **Python 3.9+** installed and in PATH
  (check: open CMD → `python --version`)

### Option A: One-Click Build
```
1. Put all files in a folder (e.g. C:\DeskTracker\)
2. Double-click build.bat
3. Wait ~60 seconds
4. Done! Your .exe is in the dist\ subfolder
```

### Option B: Manual Build
```cmd
cd C:\DeskTracker

python -m venv venv
venv\Scripts\activate

pip install -r requirements.txt

pyinstaller desktracker.spec --clean --noconfirm

copy .env dist\.env
```

---

## Deploy to Any Windows Machine

Copy **just these 2 files** to the target machine:

```
DeskTracker.exe
.env
```

No Python installation needed on the target machine. No Oracle Client needed either (uses thin mode).

---

## Configure

Edit `.env` with your actual Oracle credentials:

```env
DB_USER=scott
DB_PASS=tiger123
DB_DSN=192.168.1.50:1521/ORCLPDB1
```

The `.env` file **must be in the same folder** as `DeskTracker.exe`.

---

## Run

- **Double-click** `DeskTracker.exe`
- It runs silently in the background (no console window)
- Activity is logged to `desktracker.log` in the same folder
- Every 15 minutes, data is flushed to the `app_activity_daily` Oracle table

### Auto-Start on Windows Boot
1. Press `Win + R` → type `shell:startup` → Enter
2. Right-click → New → Shortcut
3. Browse to `DeskTracker.exe`
4. Done — it will start on every login

---

## Stop the Tracker

Since there's no console window, stop it via Task Manager:
1. `Ctrl + Shift + Esc` → Task Manager
2. Find `DeskTracker.exe` under "Background processes"
3. Right-click → End task

The tracker flushes all pending data before exiting.

---

## Dependencies Reference

| Package         | Version  | Why                                      |
|-----------------|----------|------------------------------------------|
| `psutil`        | ≥ 5.9.0  | Get process name from window PID         |
| `pywin32`       | ≥ 306    | `win32gui` / `win32process` Windows APIs |
| `pynput`        | ≥ 1.7.6  | Keyboard & mouse activity listeners      |
| `oracledb`      | ≥ 2.0.0  | Oracle DB driver (thin mode)             |
| `python-dotenv` | ≥ 1.0.0  | Load `.env` file for config              |
| `pyinstaller`   | ≥ 6.0.0  | Build the `.exe` (build-time only)       |

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `.exe` does nothing on double-click | Run from CMD: `DeskTracker.exe` — errors will print |
| `DB connection failed` in log | Check `.env` credentials and DB network access |
| `ModuleNotFoundError: xyz` | Add `'xyz'` to `hiddenimports` in `.spec`, rebuild |
| Antivirus flags/quarantines it | Add exception — PyInstaller .exe files trigger false positives |
| Missing DLL error | Install [VC++ Redistributable](https://aka.ms/vs/17/release/vc_redist.x64.exe) |
| `.env` not loading | Ensure `.env` is in the **same folder** as the `.exe` |
| Log file not created | Check folder has write permissions |

---

## If You Want a Console Window (for debugging)

In `desktracker.spec`, change:
```python
console=False,    # ← change to True
```
Then rebuild. You'll see all logs in real-time in a CMD window.
